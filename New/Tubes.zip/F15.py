def help(user):
    if user == '':
        print("1. login\n   Untuk masuk menggunakan akun")
        print("2. exit\n   Untuk keluar dari program dan kembali ke terminal")
        print("3. help\n   Untuk melihat daftar command")

    elif user == 'bandung_bondowoso':
        print("1. logout\n   Untuk keluar dari akun yang digunakan sekarang")
        print("2. summonjin\n   Untuk memanggil jin")
        print("3. hapusjin\n   Untuk menghapus jin")
        print("4. ubahjin\n   Untuk mengubah tipe jin yang tersedia")
        print("5. batchkumpul\n   Untuk mengumpulkan resource candi dengan semua jin pembangun")
        print("6. batchbangun\n   Untuk membangun candi dengan semua jin pembangun")
        print("7. laporanjin\n   Untuk mengetahui jumlah resouce candi, jumlah jin dan jin termalas atau jin terajin")
        print("8. laporancandi\n   Untuk mengetahui jumlah candi, harga candi, dan jumlah resource yang telah digunakan")
        print("9. save\n   Untuk menyimpan data permainan dalam sebuah folder")
        print("10. exit\n    Untuk keluar dari program dan kembali ke terminal")
        print("11. help\n    Untuk melihat daftar command")

    elif user == 'roro_jonggrang':
        print("1. logout\n   Untuk keluar dari akun yang digunakan sekarang")
        print("2. hancurkancandi\n   Untuk menghancurkan candi yang tersedia")
        print("3. ayamberkokok\n   Untuk menyelesaikan permainan")
        print("4. exit\n   Untuk keluar dari program dan kembali ke terminal")
        print("5. help\n   Untuk melihat daftar command")

    elif user == 'jin_pengumpul':
        print("1. logout\n   Untuk keluar dari akun yang digunakan sekarang")
        print("2. kumpul\n   Untuk mengumpulkan resource candi")
        print("3. exit\n   Untuk keluar dari program dan kembali ke terminal")
        print("4. help\n   Untuk melihat daftar command")

    elif user == 'jin_pembangun':
        print("1. logout\n   Untuk keluar dari akun yang digunakan sekarang")
        print("2. bangun\n   Untuk membangun candi")
        print("3. exit\n   Untuk keluar dari program dan kembali ke terminal")
        print("4. help\n   Untuk melihat daftar command")