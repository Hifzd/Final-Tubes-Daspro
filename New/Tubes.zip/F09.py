from primitives import hitungjin, pjglist, konso
import global_dat

def pembuat_candi():
    global global_dat
    builder = []
    for i in range(1,pjglist(global_dat.candi)):
        unique = True
        if pjglist(builder) > 0:
            for j in range(pjglist(builder)):
                if builder[j][0] == global_dat.candi[i][1]:
                    unique = False
        if unique:
            builder = konso(builder,[global_dat.candi[i][1], 0])
    return (builder)

def RankJin(adj):
    selected_jin = '-'
    data_pembuat = pembuat_candi()
    if pjglist(data_pembuat) > 0:
        for i in range(pjglist(data_pembuat)):
            count = 0
            for j in range(1,pjglist(global_dat.candi)):
                if data_pembuat[i][0] == global_dat.candi[j][1]:
                    count += 1
            data_pembuat[i][1] = count
        selected_jin, MinMax = data_pembuat[0][0], data_pembuat[0][1]
    
        for i in range(pjglist(data_pembuat)):
            if adj == 'Rajin' and data_pembuat[i][1] >= MinMax and data_pembuat[i][0] < selected_jin:
                selected_jin = data_pembuat[i][0]
            elif adj == 'Malas' and data_pembuat[i][1] <= MinMax and data_pembuat[i][0] > selected_jin:
                selected_jin = data_pembuat[i][0]

    return selected_jin

def laporanjin():
    global global_dat

    print('> Total Jin:', hitungjin(global_dat.users, 'all'))
    print('> Total Jin Pengumpul:', hitungjin(global_dat.users, 'jin_pengumpul'))
    print('> Total Jin Pembangun:', hitungjin(global_dat.users, 'jin_pembangun'))
    print('> Jin Terajin :', RankJin('Rajin'))
    print('> Jin Termalas:', RankJin('Malas'))
    print('> Jumlah Pasir:', global_dat.bahan_bangunan[1][2],'unit')
    print('> Jumlah Batu :', global_dat.bahan_bangunan[2][2],'unit')
    print('> Jumlah Air  :', global_dat.bahan_bangunan[3][2],'unit')
