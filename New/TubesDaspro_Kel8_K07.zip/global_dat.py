users = []
candi = []
bahan_bangunan = []
current_user = ['' for i in range(3)]